"""
tests/test_prompt_builder.py
-----------------------------
Unit tests for PromptBuilder.
No API calls — pure logic only.
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from prompt_builder import PromptBuilder, DIFFICULTY_LEVELS


@pytest.fixture
def builder() -> PromptBuilder:
    return PromptBuilder()


# ---------------------------------------------------------------------------
# build_explanation_prompt
# ---------------------------------------------------------------------------

class TestBuildExplanationPrompt:

    def test_contains_topic(self, builder: PromptBuilder) -> None:
        prompt = builder.build_explanation_prompt("Photosynthesis", DIFFICULTY_LEVELS[0])
        assert "Photosynthesis" in prompt

    def test_contains_difficulty(self, builder: PromptBuilder) -> None:
        difficulty = "Explain like I'm 10"
        prompt = builder.build_explanation_prompt("DNA", difficulty)
        assert difficulty in prompt

    def test_all_three_difficulty_levels_embedded(self, builder: PromptBuilder) -> None:
        for level in DIFFICULTY_LEVELS:
            prompt = builder.build_explanation_prompt("Gravity", level)
            assert level in prompt

    def test_mentions_everyday_example(self, builder: PromptBuilder) -> None:
        prompt = builder.build_explanation_prompt("Gravity", DIFFICULTY_LEVELS[0])
        assert "example" in prompt.lower()

    def test_strips_whitespace_from_topic(self, builder: PromptBuilder) -> None:
        prompt = builder.build_explanation_prompt("  Osmosis  ", DIFFICULTY_LEVELS[0])
        assert "Osmosis" in prompt
        # Should not embed raw leading/trailing spaces as part of the topic label
        assert "  Osmosis  " not in prompt

    def test_returns_non_empty_string(self, builder: PromptBuilder) -> None:
        prompt = builder.build_explanation_prompt("Atoms", DIFFICULTY_LEVELS[1])
        assert isinstance(prompt, str)
        assert len(prompt) > 0

    def test_different_difficulties_produce_different_prompts(
        self, builder: PromptBuilder
    ) -> None:
        p1 = builder.build_explanation_prompt("Gravity", DIFFICULTY_LEVELS[0])
        p2 = builder.build_explanation_prompt("Gravity", DIFFICULTY_LEVELS[2])
        assert p1 != p2


# ---------------------------------------------------------------------------
# build_quiz_prompt
# ---------------------------------------------------------------------------

class TestBuildQuizPrompt:

    def test_contains_topic(self, builder: PromptBuilder) -> None:
        prompt = builder.build_quiz_prompt("Photosynthesis")
        assert "Photosynthesis" in prompt

    def test_asks_for_three_questions(self, builder: PromptBuilder) -> None:
        prompt = builder.build_quiz_prompt("DNA")
        assert "3" in prompt

    def test_contains_format_markers(self, builder: PromptBuilder) -> None:
        prompt = builder.build_quiz_prompt("Gravity")
        for marker in ("Q1:", "Q2:", "Q3:", "Answer:"):
            assert marker in prompt

    def test_contains_option_labels(self, builder: PromptBuilder) -> None:
        prompt = builder.build_quiz_prompt("Gravity")
        for label in ("A)", "B)", "C)", "D)"):
            assert label in prompt

    def test_strips_whitespace_from_topic(self, builder: PromptBuilder) -> None:
        prompt = builder.build_quiz_prompt("  Osmosis  ")
        assert "Osmosis" in prompt
        assert "  Osmosis  " not in prompt

    def test_returns_non_empty_string(self, builder: PromptBuilder) -> None:
        prompt = builder.build_quiz_prompt("Atoms")
        assert isinstance(prompt, str)
        assert len(prompt) > 0
