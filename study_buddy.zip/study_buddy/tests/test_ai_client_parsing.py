"""
tests/test_ai_client_parsing.py
--------------------------------
Unit tests for AIStudyClient.parse_quiz_response().
No real API calls — we test the parser with hand-crafted inputs.
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest

# parse_quiz_response and the exception classes are importable without
# initialising an AIStudyClient (no credentials needed).
from ai_client import AIStudyClient, QuizParseError, QuizQuestion


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

VALID_QUIZ_RESPONSE = """
Q1: What process do plants use to make food?
A) Respiration
B) Photosynthesis
C) Digestion
D) Fermentation
Answer: B

Q2: What gas do plants absorb during photosynthesis?
A) Oxygen
B) Nitrogen
C) Carbon dioxide
D) Hydrogen
Answer: C

Q3: What is the main source of energy for photosynthesis?
A) Water
B) Soil
C) Wind
D) Sunlight
Answer: D
"""


# ---------------------------------------------------------------------------
# Happy-path tests
# ---------------------------------------------------------------------------

class TestParseQuizResponseValid:

    def test_returns_three_questions(self) -> None:
        questions = AIStudyClient.parse_quiz_response(VALID_QUIZ_RESPONSE)
        assert len(questions) == 3

    def test_returns_list_of_quiz_question(self) -> None:
        questions = AIStudyClient.parse_quiz_response(VALID_QUIZ_RESPONSE)
        for q in questions:
            assert isinstance(q, QuizQuestion)

    def test_question_text_is_correct(self) -> None:
        questions = AIStudyClient.parse_quiz_response(VALID_QUIZ_RESPONSE)
        assert questions[0].question == "What process do plants use to make food?"
        assert questions[1].question == "What gas do plants absorb during photosynthesis?"
        assert questions[2].question == "What is the main source of energy for photosynthesis?"

    def test_each_question_has_four_options(self) -> None:
        questions = AIStudyClient.parse_quiz_response(VALID_QUIZ_RESPONSE)
        for q in questions:
            assert len(q.options) == 4

    def test_options_start_with_letter(self) -> None:
        questions = AIStudyClient.parse_quiz_response(VALID_QUIZ_RESPONSE)
        for q in questions:
            for opt in q.options:
                assert opt[0] in ("A", "B", "C", "D")

    def test_answer_letters_are_correct(self) -> None:
        questions = AIStudyClient.parse_quiz_response(VALID_QUIZ_RESPONSE)
        assert questions[0].answer == "B"
        assert questions[1].answer == "C"
        assert questions[2].answer == "D"

    def test_answer_is_uppercase(self) -> None:
        # Even if the AI responds with lowercase, the parser should uppercase it
        lowercase_response = VALID_QUIZ_RESPONSE.replace("Answer: B", "Answer: b")
        questions = AIStudyClient.parse_quiz_response(lowercase_response)
        assert questions[0].answer == "B"

    def test_extra_whitespace_is_tolerated(self) -> None:
        """Leading/trailing blank lines around the block should not break parsing."""
        padded = "\n\n\n" + VALID_QUIZ_RESPONSE + "\n\n"
        questions = AIStudyClient.parse_quiz_response(padded)
        assert len(questions) == 3


# ---------------------------------------------------------------------------
# Error-path tests
# ---------------------------------------------------------------------------

class TestParseQuizResponseInvalid:

    def test_empty_string_raises_quiz_parse_error(self) -> None:
        with pytest.raises(QuizParseError):
            AIStudyClient.parse_quiz_response("")

    def test_only_two_questions_raises_quiz_parse_error(self) -> None:
        two_q = """
Q1: Question one?
A) Option 1
B) Option 2
C) Option 3
D) Option 4
Answer: A

Q2: Question two?
A) Option 1
B) Option 2
C) Option 3
D) Option 4
Answer: B
"""
        with pytest.raises(QuizParseError, match="Expected 3 question blocks"):
            AIStudyClient.parse_quiz_response(two_q)

    def test_missing_answer_line_raises_quiz_parse_error(self) -> None:
        no_answer = """
Q1: What is 2+2?
A) 3
B) 4
C) 5
D) 6

Q2: What colour is the sky?
A) Red
B) Green
C) Blue
D) Yellow

Q3: How many sides does a triangle have?
A) 2
B) 3
C) 4
D) 5
Answer: B
"""
        with pytest.raises(QuizParseError, match="missing an 'Answer:' line"):
            AIStudyClient.parse_quiz_response(no_answer)

    def test_only_three_options_raises_quiz_parse_error(self) -> None:
        three_opts = """
Q1: Question one?
A) Option 1
B) Option 2
C) Option 3
Answer: A

Q2: Question two?
A) Option 1
B) Option 2
C) Option 3
D) Option 4
Answer: B

Q3: Question three?
A) Option 1
B) Option 2
C) Option 3
D) Option 4
Answer: C
"""
        with pytest.raises(QuizParseError, match="exactly 4 options"):
            AIStudyClient.parse_quiz_response(three_opts)

    def test_invalid_answer_letter_raises_quiz_parse_error(self) -> None:
        bad_answer = VALID_QUIZ_RESPONSE.replace("Answer: B", "Answer: Z")
        with pytest.raises(QuizParseError, match="invalid answer letter"):
            AIStudyClient.parse_quiz_response(bad_answer)

    def test_plain_text_no_markers_raises_quiz_parse_error(self) -> None:
        with pytest.raises(QuizParseError):
            AIStudyClient.parse_quiz_response(
                "Sure! Here are some questions about photosynthesis..."
            )
