"""
check_config.py
---------------
Run this script to verify your IBM watsonx credentials BEFORE starting the app.

Usage:
    python check_config.py

It checks that:
  1. The .env file exists in the correct location
  2. IBM_API_KEY is set
  3. IBM_PROJECT_ID is set
  4. The IBM watsonx SDK can reach the API with those credentials
"""

import os
import sys

# ── Step 1: locate the .env file ────────────────────────────────────────────

HERE    = os.path.dirname(os.path.abspath(__file__))
ENV_PATH = os.path.join(HERE, ".env")

print("=" * 60)
print("  AI Study Buddy - Configuration Check")
print("=" * 60)
print()
print(f"Looking for .env at:\n  {ENV_PATH}")
print()

if not os.path.exists(ENV_PATH):
    print("[FAIL]  .env file NOT found.\n")
    print("Fix:")
    print(f"  1. Go to this folder:  {HERE}")
    print("  2. Copy .env.example to .env")
    print("     Windows:   copy .env.example .env")
    print("     Mac/Linux: cp .env.example .env")
    print("  3. Open .env and fill in IBM_API_KEY and IBM_PROJECT_ID")
    sys.exit(1)

print("[ OK ]  .env file found.")
print()

# ── Step 2: load and validate variables ─────────────────────────────────────

try:
    from dotenv import load_dotenv
except ImportError:
    print("[FAIL]  python-dotenv is not installed.")
    print("    Run:  pip install python-dotenv")
    sys.exit(1)

load_dotenv(dotenv_path=ENV_PATH, override=False)

api_key    = os.getenv("IBM_API_KEY", "").strip()
project_id = os.getenv("IBM_PROJECT_ID", "").strip()
url        = os.getenv("IBM_URL", "https://us-south.ml.cloud.ibm.com").strip()

ok = True

if not api_key:
    print("[FAIL]  IBM_API_KEY is missing or empty in your .env file.")
    print("    Get it at: https://cloud.ibm.com/iam/apikeys")
    ok = False
else:
    masked = api_key[:4] + "*" * (len(api_key) - 8) + api_key[-4:] if len(api_key) > 8 else "****"
    print(f"[ OK ]  IBM_API_KEY      = {masked}  ({len(api_key)} characters)")

if not project_id:
    print("[FAIL]  IBM_PROJECT_ID is missing or empty in your .env file.")
    print("    Get it at: https://dataplatform.cloud.ibm.com/wx/home")
    print("               → open your project → Manage → General → Project ID")
    ok = False
else:
    print(f"[ OK ]  IBM_PROJECT_ID   = {project_id}")

print(f"[ INFO] IBM_URL           = {url}")
print()

if not ok:
    print("Please fix the missing values in your .env file, then run this")
    print("script again before starting the app.")
    sys.exit(1)

# ── Step 3: test live connection ─────────────────────────────────────────────

print("Connecting to IBM watsonx.ai to test credentials …")
print("(This may take a few seconds.)")
print()

try:
    from ibm_watsonx_ai import Credentials
    from ibm_watsonx_ai.foundation_models import ModelInference
    from ibm_watsonx_ai.foundation_models.schema import TextGenParameters
except ImportError:
    print("[FAIL]  ibm-watsonx-ai SDK is not installed.")
    print("    Run:  pip install ibm-watsonx-ai")
    sys.exit(1)

try:
    credentials = Credentials(api_key=api_key, url=url)
    params = TextGenParameters(max_new_tokens=10, temperature=0.1)
    model = ModelInference(
        model_id="ibm/granite-13b-instruct-v2",
        credentials=credentials,
        project_id=project_id,
        params=params,
    )
    result = model.generate_text(prompt="Say: OK")
    print(f"[ OK ]  Connection successful! IBM watsonx responded: {result!r}")
    print()
    print("Your credentials are working correctly.")
    print("You can now start the app with:  streamlit run app.py")

except Exception as exc:
    print(f"[FAIL]  Connection failed: {exc}")
    print()
    print("Common causes:")
    print("  • IBM_API_KEY is wrong or expired — generate a new one at:")
    print("    https://cloud.ibm.com/iam/apikeys")
    print("  • IBM_PROJECT_ID is wrong — double-check in your watsonx project:")
    print("    https://dataplatform.cloud.ibm.com/wx/home → Manage → General")
    print("  • IBM_URL does not match your account's region")
    sys.exit(1)
