"""
prompt_builder.py
-----------------
Builds text prompts that are sent to the IBM watsonx LLM.
Keeping prompt construction separate from the API client makes
it easy to read, tweak, and test without making any real API calls.
"""

from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DIFFICULTY_LEVELS: list[str] = [
    "Explain like I'm 10",
    "Explain simply",
    "Explain in detail",
]

QUIZ_FORMAT_INSTRUCTIONS: str = """\
Use this EXACT format for each question — do not deviate:

Q1: [question text]
A) [option]
B) [option]
C) [option]
D) [option]
Answer: [correct letter only, e.g. A]

Q2: [question text]
A) [option]
B) [option]
C) [option]
D) [option]
Answer: [correct letter only, e.g. B]

Q3: [question text]
A) [option]
B) [option]
C) [option]
D) [option]
Answer: [correct letter only, e.g. C]

Do not add any text before Q1 or after the Answer line of Q3.\
"""


# ---------------------------------------------------------------------------
# PromptBuilder class
# ---------------------------------------------------------------------------

@dataclass
class PromptBuilder:
    """
    Builds prompts for the AI Study Buddy.

    All methods are pure functions of their inputs — no side effects,
    no I/O — which makes them trivially easy to unit-test.
    """

    difficulty_levels: list[str] = field(default_factory=lambda: list(DIFFICULTY_LEVELS))

    def build_explanation_prompt(self, topic: str, difficulty: str) -> str:
        """
        Returns a prompt that asks the LLM to explain *topic* at the
        requested *difficulty* level, including a real-world example.

        Args:
            topic:      The concept, text, or study notes entered by the user.
            difficulty: One of DIFFICULTY_LEVELS.

        Returns:
            A formatted prompt string ready to be sent to the LLM.
        """
        return (
            f"You are a friendly, patient teacher.\n\n"
            f'Explain the following topic using this style: "{difficulty}".\n\n'
            f"Topic:\n{topic.strip()}\n\n"
            f"Your response MUST include:\n"
            f"1. A clear explanation (3-5 sentences).\n"
            f"2. A real-world, everyday example that anyone could understand.\n\n"
            f"Write in plain paragraphs. Keep the language warm and encouraging.\n"
            f"Do not use bullet points or numbered lists in your explanation."
        )

    def build_quiz_prompt(self, topic: str) -> str:
        """
        Returns a prompt that asks the LLM to generate exactly 3
        multiple-choice questions about *topic* in a strict, parseable format.

        Args:
            topic: The concept the quiz should be about.

        Returns:
            A formatted prompt string ready to be sent to the LLM.
        """
        return (
            f'Based on the topic: "{topic.strip()}"\n\n'
            f"Generate exactly 3 multiple-choice quiz questions to test "
            f"basic understanding of this topic.\n\n"
            f"{QUIZ_FORMAT_INSTRUCTIONS}"
        )
