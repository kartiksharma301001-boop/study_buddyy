# -*- coding: utf-8 -*-
"""
app.py
------
Streamlit UI for the AI Study Buddy application.

Run with:
    streamlit run app.py

All IBM watsonx / AI logic lives in ai_client.py and prompt_builder.py —
this file is responsible ONLY for rendering the UI and wiring up user actions.
"""

import sys
import os
from datetime import datetime

import streamlit as st

# Allow running from the study_buddy directory directly
sys.path.insert(0, os.path.dirname(__file__))

from prompt_builder import DIFFICULTY_LEVELS
from ai_client import (
    AIStudyClient,
    AIClientError,
    EmptyResponseError,
    QuizParseError,
    QuizQuestion,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAX_TOPIC_LENGTH: int = 2_000
APP_TITLE: str = "🎓 AI Study Buddy"
APP_SUBTITLE: str = "Paste any topic or notes — get a simple explanation and a mini quiz!"


# ---------------------------------------------------------------------------
# Session state helpers
# ---------------------------------------------------------------------------

def init_session_state() -> None:
    """Initialise all session-state keys on the very first run."""
    defaults: dict = {
        "history":             [],      # list of HistoryEntry dicts
        "current_topic":       "",
        "current_difficulty":  DIFFICULTY_LEVELS[0],
        "current_explanation": "",
        "current_quiz":        [],      # list of QuizQuestion
        "quiz_generated":      False,
        "ai_client":           None,    # lazy-initialised on first use
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def add_to_history(topic: str, difficulty: str, explanation: str) -> None:
    """Append a new entry to the session history list."""
    st.session_state.history.append({
        "topic":       topic,
        "difficulty":  difficulty,
        "explanation": explanation,
        "timestamp":   datetime.now().strftime("%H:%M"),
    })


def get_ai_client() -> AIStudyClient:
    """
    Return the shared AIStudyClient, creating it on the first call.
    Raises AIClientError if credentials are missing or invalid.
    """
    if st.session_state.ai_client is None:
        st.session_state.ai_client = AIStudyClient()
    return st.session_state.ai_client


def show_credentials_help(detail: str = "") -> None:
    """Render a step-by-step setup guide when IBM credentials are missing."""
    # Compute the exact expected .env path so the user knows exactly where to create it
    _env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")

    st.error("🔑 IBM watsonx credentials are not configured.")

    if detail:
        st.warning(f"**Details:** {detail}")

    st.markdown(
        f"""
### What you need to do — 4 simple steps

---

**Step 1 — Create your `.env` file**

Create a plain text file at this exact location on your computer:

```
{_env_path}
```

The file must contain these three lines (replace the values in angle brackets):

```
IBM_API_KEY=<your-api-key>
IBM_PROJECT_ID=<your-project-id>
IBM_URL=https://us-south.ml.cloud.ibm.com
```

> **Tip:** A template file called `.env.example` already exists next to `app.py`.
> Just copy it and rename the copy to `.env`, then fill in the two values.

---

**Step 2 — Get your `IBM_API_KEY`**

1. Open [cloud.ibm.com/iam/apikeys](https://cloud.ibm.com/iam/apikeys) *(log in with your IBM Cloud account)*
2. Click **"Create an IBM Cloud API key"**
3. Give it any name, e.g. `study-buddy`
4. Click **Create**, then **Copy** or **Download** the key — it is shown **only once**
5. Paste the copied key as the value of `IBM_API_KEY=` in your `.env` file

---

**Step 3 — Get your `IBM_PROJECT_ID`**

1. Open [dataplatform.cloud.ibm.com/wx/home](https://dataplatform.cloud.ibm.com/wx/home)
   *(use the same IBM Cloud account)*
2. Click an existing project, or create a new one *(type: watsonx.ai Runtime)*
3. Inside the project, click **Manage** → **General**
4. Copy the **Project ID** (it looks like: `a1b2c3d4-1234-5678-abcd-ef0123456789`)
5. Paste it as the value of `IBM_PROJECT_ID=` in your `.env` file

---

**Step 4 — Restart the app**

After saving your `.env` file, press **Ctrl + C** in the terminal to stop the app,
then run it again:

```
streamlit run app.py
```
        """,
        unsafe_allow_html=False,
    )
    st.stop()


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_topic(topic: str) -> str | None:
    """
    Validate the topic string.

    Returns:
        None if valid, or an error message string if invalid.
    """
    if not topic or not topic.strip():
        return "⚠️ Please enter a topic or paste some study notes first."
    if len(topic) > MAX_TOPIC_LENGTH:
        return (
            f"⚠️ Your input is {len(topic):,} characters long. "
            f"Please shorten it to {MAX_TOPIC_LENGTH:,} characters or less."
        )
    return None


# ---------------------------------------------------------------------------
# Rendering helpers
# ---------------------------------------------------------------------------

def render_sidebar() -> None:
    """Render the session history list in the sidebar."""
    with st.sidebar:
        st.header("📚 Session History")
        if not st.session_state.history:
            st.caption("No topics yet. Ask your first question!")
            return

        for i, entry in enumerate(reversed(st.session_state.history)):
            with st.expander(
                f"[{entry['timestamp']}] {entry['topic'][:50]}{'…' if len(entry['topic']) > 50 else ''}",
                expanded=(i == 0),
            ):
                st.caption(f"**Level:** {entry['difficulty']}")
                st.write(entry["explanation"])


def render_quiz(quiz: list[QuizQuestion]) -> None:
    """Render 3 quiz question cards."""
    st.subheader("📝 Mini Quiz")
    for i, q in enumerate(quiz, start=1):
        with st.container(border=True):
            st.markdown(f"**Question {i}:** {q.question}")
            for option in q.options:
                st.write(option)
            st.success(f"✅ Correct answer: **{q.answer}**")


def render_explanation(explanation: str) -> None:
    """Render the AI explanation inside a styled card."""
    st.subheader("💡 Explanation")
    with st.container(border=True):
        st.write(explanation)


# ---------------------------------------------------------------------------
# Main app
# ---------------------------------------------------------------------------

def main() -> None:
    st.set_page_config(page_title=APP_TITLE, page_icon="🎓", layout="wide")
    init_session_state()

    # ── Sidebar ─────────────────────────────────────────────────────────────
    render_sidebar()

    # ── Header ──────────────────────────────────────────────────────────────
    st.title(APP_TITLE)
    st.caption(APP_SUBTITLE)
    st.divider()

    # ── Input area ──────────────────────────────────────────────────────────
    col_input, col_options = st.columns([3, 1])

    with col_input:
        topic = st.text_area(
            label="📖 Topic or Study Notes",
            placeholder=(
                "e.g. Photosynthesis\n\n"
                "or paste in a paragraph from your textbook…"
            ),
            height=160,
            max_chars=MAX_TOPIC_LENGTH,
            help=f"Maximum {MAX_TOPIC_LENGTH:,} characters.",
        )

    with col_options:
        difficulty = st.selectbox(
            label="🎚️ Explanation Level",
            options=DIFFICULTY_LEVELS,
            index=0,
            help="How detailed should the explanation be?",
        )
        st.write("")  # spacer
        explain_clicked = st.button(
            "✨ Explain It!",
            type="primary",
            use_container_width=True,
        )

    # ── Explain button handler ───────────────────────────────────────────────
    if explain_clicked:
        error = validate_topic(topic)
        if error:
            st.warning(error)
        else:
            with st.spinner("🤔 Thinking…"):
                try:
                    client = get_ai_client()
                    explanation = client.get_explanation(topic, difficulty)

                    # Persist to session state
                    st.session_state.current_topic       = topic
                    st.session_state.current_difficulty  = difficulty
                    st.session_state.current_explanation = explanation
                    st.session_state.current_quiz        = []
                    st.session_state.quiz_generated      = False

                    add_to_history(topic, difficulty, explanation)

                except AIClientError as exc:
                    err_msg = str(exc)
                    if "IBM_API_KEY" in err_msg or "IBM_PROJECT_ID" in err_msg or "Missing credential" in err_msg:
                        show_credentials_help(detail=err_msg)
                    else:
                        st.error(f"❌ Could not reach the AI service. {exc}")
                        st.stop()

    # ── Explanation output ───────────────────────────────────────────────────
    if st.session_state.current_explanation:
        render_explanation(st.session_state.current_explanation)

        st.write("")

        # ── Quiz section ─────────────────────────────────────────────────────
        quiz_clicked = st.button(
            "🧪 Generate Quiz",
            disabled=False,
            help="Generate 3 short quiz questions on the current topic.",
        )

        if quiz_clicked:
            with st.spinner("📝 Generating quiz questions…"):
                try:
                    client = get_ai_client()
                    quiz = client.get_quiz_questions(st.session_state.current_topic)
                    st.session_state.current_quiz   = quiz
                    st.session_state.quiz_generated = True

                except QuizParseError as exc:
                    st.error(
                        f"❌ Could not generate the quiz. "
                        f"The AI response was in an unexpected format. ({exc})"
                    )
                except AIClientError as exc:
                    err_msg = str(exc)
                    if "IBM_API_KEY" in err_msg or "IBM_PROJECT_ID" in err_msg or "Missing credential" in err_msg:
                        show_credentials_help(detail=err_msg)
                    else:
                        st.error(f"❌ Could not reach the AI service. {exc}")

        if st.session_state.quiz_generated and st.session_state.current_quiz:
            render_quiz(st.session_state.current_quiz)


if __name__ == "__main__":
    main()
