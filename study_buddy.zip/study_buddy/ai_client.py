"""
ai_client.py
------------
Handles all communication with the IBM watsonx.ai LLM (SDK >= 1.1.2).

Responsibilities:
  - Load credentials from the .env file via python-dotenv.
  - Send prompts to the LLM and return plain-text responses.
  - Parse the raw quiz response text into structured quiz question dicts.
  - Raise clearly-named exceptions so the UI layer can show friendly messages.

Credentials required in .env (see .env.example):
  IBM_API_KEY      – IBM Cloud IAM API key
  IBM_PROJECT_ID   – watsonx.ai project ID
  IBM_URL          – (optional) regional endpoint, defaults to us-south
"""

import os
import re
from dataclasses import dataclass, field

# NOTE: dotenv and ibm_watsonx_ai are imported lazily inside __post_init__ so
# that the exception classes and parse_quiz_response() can be imported by tests
# without requiring those packages to be installed.
from prompt_builder import PromptBuilder


# ---------------------------------------------------------------------------
# Custom Exceptions
# ---------------------------------------------------------------------------

class AIClientError(Exception):
    """Raised when the IBM watsonx API call itself fails."""


class EmptyResponseError(AIClientError):
    """Raised when the API returns a 200 OK but the response text is empty."""


class QuizParseError(AIClientError):
    """Raised when the quiz response cannot be parsed into 3 valid questions."""


# ---------------------------------------------------------------------------
# Data type for a parsed quiz question
# ---------------------------------------------------------------------------

@dataclass
class QuizQuestion:
    """Represents one multiple-choice question with 4 options and an answer."""
    question: str
    options: list[str]          # always length 4, e.g. ["A) ...", "B) ...", ...]
    answer: str                 # correct letter, e.g. "B"


# ---------------------------------------------------------------------------
# AIStudyClient
# ---------------------------------------------------------------------------

@dataclass
class AIStudyClient:
    """
    Thin wrapper around IBM watsonx.ai ModelInference.

    Usage:
        client = AIStudyClient()
        explanation = client.get_explanation("Photosynthesis", "Explain like I'm 10")
        quiz        = client.get_quiz_questions("Photosynthesis")
    """

    model_id: str = "ibm/granite-13b-instruct-v2"
    max_new_tokens: int = 800
    temperature: float = 0.7

    # Internal — built in __post_init__
    # _model type is 'Any' here because ModelInference is imported lazily
    _model: object = field(init=False, repr=False)
    _prompt_builder: PromptBuilder = field(init=False, repr=False)

    def __post_init__(self) -> None:
        # Lazy imports — keeps the module importable without these packages
        # (tests can import exceptions and parse_quiz_response without the SDK)
        from dotenv import load_dotenv  # noqa: PLC0415
        from ibm_watsonx_ai import Credentials  # noqa: PLC0415
        from ibm_watsonx_ai.foundation_models import ModelInference  # noqa: PLC0415
        from ibm_watsonx_ai.foundation_models.schema import TextGenParameters  # noqa: PLC0415

        # Always load the .env that sits next to THIS file (ai_client.py).
        # Using an explicit path means the app works no matter which directory
        # the user runs `streamlit run app.py` from.
        _env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
        load_dotenv(dotenv_path=_env_path, override=False)

        api_key    = os.getenv("IBM_API_KEY", "").strip()
        project_id = os.getenv("IBM_PROJECT_ID", "").strip()
        url        = os.getenv("IBM_URL", "https://us-south.ml.cloud.ibm.com").strip()

        # Produce a specific, actionable error for each missing variable
        missing: list[str] = []
        if not api_key:
            missing.append("IBM_API_KEY")
        if not project_id:
            missing.append("IBM_PROJECT_ID")
        if missing:
            raise AIClientError(
                f"Missing credential(s) in your .env file: {', '.join(missing)}\n"
                f"Expected .env location: {_env_path}\n"
                "Copy .env.example to .env and fill in both values."
            )

        try:
            # SDK >= 1.1.2: pass credentials + project_id directly to ModelInference
            credentials = Credentials(api_key=api_key, url=url)
            params = TextGenParameters(
                max_new_tokens=self.max_new_tokens,
                temperature=self.temperature,
            )
            self._model = ModelInference(
                model_id=self.model_id,
                credentials=credentials,
                project_id=project_id,
                params=params,
            )
        except Exception as exc:
            raise AIClientError(f"Failed to initialise IBM watsonx client: {exc}") from exc

        self._prompt_builder = PromptBuilder()

    # ------------------------------------------------------------------
    # Public methods
    # ------------------------------------------------------------------

    def get_explanation(self, topic: str, difficulty: str) -> str:
        """
        Ask the LLM to explain *topic* at the given *difficulty* level.

        Returns:
            The explanation text as a plain string.

        Raises:
            AIClientError, EmptyResponseError
        """
        prompt = self._prompt_builder.build_explanation_prompt(topic, difficulty)
        return self._call_api(prompt)

    def get_quiz_questions(self, topic: str) -> list[QuizQuestion]:
        """
        Ask the LLM to generate 3 quiz questions about *topic*.

        Returns:
            A list of exactly 3 QuizQuestion objects.

        Raises:
            AIClientError, EmptyResponseError, QuizParseError
        """
        prompt = self._prompt_builder.build_quiz_prompt(topic)
        raw    = self._call_api(prompt)
        return self.parse_quiz_response(raw)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _call_api(self, prompt: str) -> str:
        """
        Send *prompt* to IBM watsonx and return the generated text.

        Raises:
            AIClientError  – on any SDK / network error.
            EmptyResponseError – if the returned text is blank.
        """
        try:
            response = self._model.generate_text(prompt=prompt)
        except Exception as exc:
            raise AIClientError(f"IBM watsonx API call failed: {exc}") from exc

        text = (response or "").strip()
        if not text:
            raise EmptyResponseError("The AI returned an empty response. Please try again.")
        return text

    # ------------------------------------------------------------------
    # Static / class helpers (testable without a live API)
    # ------------------------------------------------------------------

    @staticmethod
    def parse_quiz_response(raw_text: str) -> list[QuizQuestion]:
        """
        Parse the raw LLM quiz output into a list of QuizQuestion objects.

        Expected format (enforced by the quiz prompt):
            Q1: <question>
            A) <option>
            B) <option>
            C) <option>
            D) <option>
            Answer: <letter>
            Q2: ...
            Q3: ...

        Raises:
            QuizParseError if the text cannot be parsed into exactly 3 questions.
        """
        questions: list[QuizQuestion] = []

        # Split on Q1/Q2/Q3 markers (case-insensitive)
        blocks = re.split(r"(?i)\bQ[1-3]\s*:\s*", raw_text.strip())

        # First element is empty string before "Q1:"
        blocks = [b.strip() for b in blocks if b.strip()]

        if len(blocks) != 3:
            raise QuizParseError(
                f"Expected 3 question blocks, found {len(blocks)}. "
                "The AI response may not have followed the required format."
            )

        for idx, block in enumerate(blocks, start=1):
            lines = [ln.strip() for ln in block.splitlines() if ln.strip()]

            # First non-empty line is the question text
            if not lines:
                raise QuizParseError(f"Question {idx} block is empty.")
            question_text = lines[0]

            # Collect A) B) C) D) lines
            option_pattern = re.compile(r"^[A-Da-d]\)")
            options = [ln for ln in lines if option_pattern.match(ln)]

            # Collect answer line
            answer_lines = [
                ln for ln in lines
                if re.match(r"(?i)^answer\s*:", ln)
            ]

            if len(options) != 4:
                raise QuizParseError(
                    f"Question {idx} must have exactly 4 options; found {len(options)}."
                )
            if not answer_lines:
                raise QuizParseError(f"Question {idx} is missing an 'Answer:' line.")

            answer_raw = re.sub(r"(?i)^answer\s*:\s*", "", answer_lines[0]).strip()
            answer_letter = answer_raw[0].upper() if answer_raw else ""

            if answer_letter not in ("A", "B", "C", "D"):
                raise QuizParseError(
                    f"Question {idx} has an invalid answer letter: '{answer_letter}'."
                )

            questions.append(
                QuizQuestion(
                    question=question_text,
                    options=options,
                    answer=answer_letter,
                )
            )

        return questions
